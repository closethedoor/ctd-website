<!doctype html>  
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->   
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge;chrome=1" />
<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />

<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif:400,400italic|Lato:400,700" />
<link rel="stylesheet" media="screen" type="text/css" href="/packages/theme_slate/themes/slate/columnal.css" />
<link rel="stylesheet" media="screen" type="text/css" href="/files/cache/css/slate/typography.css" />
<link rel="stylesheet" media="screen" type="text/css" href="/files/cache/css/slate/main.css" />

<!-- Custom for CtD -->
<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

<!-- Skins -->
<!--<link rel="stylesheet" media="screen" type="text/css" href="/packages/theme_slate/themes/slate/skins/minimal/minimal.css" />-->
<!--<link rel="stylesheet" media="screen" type="text/css" href="/packages/theme_slate/themes/slate/skins/minimal-dark/minimal-dark.css" />-->
<!--<link rel="stylesheet" media="screen" type="text/css" href="/packages/theme_slate/themes/slate/skins/minimal-grunge/minimal-grunge.css" />-->

<!-- Fixes for IE -->
<!--[if lt IE 9]>
<link rel="stylesheet" media="screen" type="text/css" href="/packages/theme_slate/themes/slate/ie.css" />
<![endif]-->
<!-- use "fixed-984px-ie.css" or "fixed-960px-ie.css for a 984px or 960px fixed width for IE6 and 7 -->
<!--[if lte IE 7]>
<link rel="stylesheet" media="screen" type="text/css" href="/packages/theme_slate/themes/slate/fixed-984px-ie.css" />
<![endif]-->

<link rel="stylesheet" media="screen" type="text/css" href="/packages/theme_slate/themes/slate/mobile.css" />


<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>Close the Door :: Home</title>
<meta name="description" content="" />
<meta name="generator" content="concrete5 - 5.6.2.1" />
<script type="text/javascript">
var CCM_DISPATCHER_FILENAME = '/index.php';var CCM_CID = 1;var CCM_EDIT_MODE = false;var CCM_ARRANGE_MODE = false;var CCM_IMAGE_PATH = "/updates/concrete5.6.2.1_updater/concrete/images";
var CCM_TOOLS_PATH = "/index.php/tools/required";
var CCM_BASE_URL = "http://ctd-staging.maisey.uk";
var CCM_REL = "";

</script>

<link rel="stylesheet" type="text/css" href="/updates/concrete5.6.2.1_updater/concrete/css/ccm.base.css?v=b4f44e4901a182db06e4752ec08f50c2" />
<script type="text/javascript" src="/updates/concrete5.6.2.1_updater/concrete/js/jquery.js?v=b4f44e4901a182db06e4752ec08f50c2"></script>
<script type="text/javascript" src="/updates/concrete5.6.2.1_updater/concrete/js/ccm.base.js?v=b4f44e4901a182db06e4752ec08f50c2"></script>
<style type="text/css"> 
#blockStyle1000MainLayout1Cell1Layout2Cell262 {background-repeat:no-repeat; margin:0 30px 0 30px; } 
#areaStyleColumnTwoLayout1Cell1Layout2Cell446 {background-repeat:no-repeat; margin:0 0 0 10px; } 
#ccm-layout-main:layout1:cell1-59-2 .ccm-layout-col-spacing { margin:0px 10px } 
</style>
<style type="text/css"> 
#blockStyle1015Main67 {text-align:right; background-repeat:no-repeat; margin:0 0 0 20px; } 
</style>
<link rel="stylesheet" type="text/css" href="/packages/unoslider/blocks/unoslider/templates/elegant/css/unoslider.css?v=b4f44e4901a182db06e4752ec08f50c2" />
<link rel="stylesheet" type="text/css" href="/packages/unoslider/blocks/unoslider/templates/elegant/css/themes.css?v=b4f44e4901a182db06e4752ec08f50c2" />
<script type="text/javascript" src="/packages/unoslider/blocks/unoslider/templates/elegant/js/unoslider.js?v=b4f44e4901a182db06e4752ec08f50c2"></script>
<link rel="stylesheet" type="text/css" href="/packages/jb_smooth/blocks/jb_smooth/css/smoothDivScroll.css?v=b4f44e4901a182db06e4752ec08f50c2" />
<link rel="stylesheet" type="text/css" href="/packages/jb_smooth/blocks/jb_smooth/css/magnific.css?v=b4f44e4901a182db06e4752ec08f50c2" />
<link rel="stylesheet" type="text/css" href="/packages/jb_smooth/blocks/jb_smooth/css/smooth.css?v=b4f44e4901a182db06e4752ec08f50c2" />
<link rel="stylesheet" type="text/css" href="/updates/concrete5.6.2.1_updater/concrete/css/jquery.ui.css?v=b4f44e4901a182db06e4752ec08f50c2" />
<script type="text/javascript" src="/updates/concrete5.6.2.1_updater/concrete/js/jquery.ui.js?v=b4f44e4901a182db06e4752ec08f50c2"></script>
<script type="text/javascript" src="/packages/jb_smooth/blocks/jb_smooth/js_manual/jquery.kinetic.js?v=b4f44e4901a182db06e4752ec08f50c2"></script>
<script type="text/javascript" src="/packages/jb_smooth/blocks/jb_smooth/js_manual/jquery.mousewheel.min.js?v=b4f44e4901a182db06e4752ec08f50c2"></script>
<script type="text/javascript" src="/packages/jb_smooth/blocks/jb_smooth/js_manual/smooth.js?v=b4f44e4901a182db06e4752ec08f50c2"></script>

<script type="text/javascript" src="/packages/theme_slate/themes/slate/js/superfish.js"></script>

<!-- FancyBox -->
<script type="text/javascript" src="/packages/theme_slate/themes/slate/js/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
<script type="text/javascript" src="/packages/theme_slate/themes/slate/js/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<link rel="stylesheet" media="screen" type="text/css" href="/packages/theme_slate/themes/slate/js/fancybox/jquery.fancybox-1.3.4.css" />

<!--[if IE]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<script type="text/javascript" src="/packages/theme_slate/themes/slate/js/functions.js"></script>

</head>

<body id="home" class="page1" >

<div id="container">

	<header>
    	<div id="logo">
<a href="/" title="Close the Door">
<a href="/"><img border="0" class="ccm-image-block" alt="Close the Door" src="/files/8014/4170/4472/site_logo_2015_v1.png" width="400" height="87" /></a></a>
        </div><!-- #logo ends -->
        <div id="header-area">
        		<div id="blockStyle1015Main67" class=" ccm-block-styles" >
<img border="0" class="ccm-image-block" alt="Climate Week Best Campaign 2012" src="/files/9313/5991/3182/topright-banner.png" width="420" height="90" /></div>        </div><!-- #header-area ends -->

    </header><!-- header ends -->
    
    <nav>
    	<ul class="sf-menu"><li class="nav-selected nav-path-selected"><a class="nav-selected nav-path-selected"  href="/">Home</a></li><li><a href="/about-us/"  >About us</a><ul><li><a href="/about-us/contact-us/"  >Contact</a></li><li><a href="/about-us/faqs/"  >FAQs</a></li><li><a href="/about-us/our-research/"  >Facts & Research</a></li><li><a href="/about-us/materials/"  >Materials and media</a></li></ul></li><li><a href="/get-involved/"  >Get involved</a><ul><li><a href="/get-involved/retailers/"  >Retailers</a></li><li><a href="/get-involved/campaigners/"  >Consumers</a></li><li><a href="/get-involved/campaigners1/"  >Campaigners</a></li></ul></li><li><a href="/support/"  >Supporters</a><ul><li><a href="/support/participating-retailers/"  >Participating retailers</a></li><li><a href="/support/endorsements/"  >Endorsements</a></li></ul></li><li><a href="/news/"  >News</a></li><li><a href="/search/"  >Search</a></li></ul>        <div class="clearboth">&nbsp;</div>
    </nav><!-- nav ends -->
    
    <div id="feature">
                    </div><!-- #feature ends -->
        
    <div id="wrapper">
    
    	<div class="row">
            <div class="col_4">
                <div id="ccm-layout-wrapper-1343" class="ccm-layout-wrapper"><div id="ccm-layout-columnone-28-1" class="ccm-layout ccm-layout-table  ccm-layout-name-ColumnOne-Layout-1 "><div class="ccm-layout-row ccm-layout-row-1"><div class="ccm-layout-28-col-1 ccm-layout-cell ccm-layout-col ccm-layout-col-1 first" style="width:100%"><h2 style="text-align: left;"><span style="color: #cc1629;">Retailers</span></h2>
<p style="text-align: left;">The <a title="Our research" href="http://www.closethedoor.org.uk//index.php?cID=140">facts are clear</a>. Closing your door can:</p>
<ul>
<li><span style="line-height: 1.5;">Save money</span></li>
<li><a style="line-height: 1.5;" title="FAQs" href="http://www.closethedoor.org.uk/about-us/faqs#airpollution">Cut down air pollution hazards</a></li>
<li><span style="line-height: 1.5;">Demonstrate environmental responsibility</span></li>
<li><span style="line-height: 1.5;">Make customers comfortable</span></li>
<li><span style="line-height: 1.5;">Provide healthy working conditions for staff</span></li>
<li><span style="line-height: 1.5;">Cut down on shoplifting</span></li>
</ul>
<p><span style="line-height: 1.5;">Whether you're an independent or a large chain, join some of the </span><a title="Participating retailers" href="http://www.closethedoor.org.uk//index.php?cID=305"><span style="line-height: 1.5;">most successful high street retailers</span></a><span style="line-height: 1.5;">. We </span><span style="line-height: 1.5;">can provide you with help and advice so this doesn't impact footfall or profit, as well as positive publicity through this page, national and local media and our social networks. If you have questions, read <a title="FAQs" href="http://www.closethedoor.org.uk//index.php?cID=162">our FAQs</a>.</span></p>
<div id="HTMLBlock1471" class="HTMLBlock">
<div align="center">
<style scoped>
.ctd-button {
  color: white;
  background: rgb(22, 117, 49);
  font-size: 125%;
}
</style>
<a class="ctd-button pure-button" href="/get-involved/retailers/">
    <i class="fa fa-tv"></i>
    Retailer's introduction
</a>
</div></div></div><div class="ccm-spacer"></div></div></div></div>            </div><!-- .col_4 ends -->
            <div class="col_4">
                <div id="ccm-layout-wrapper-1344" class="ccm-layout-wrapper"><div id="ccm-layout-columntwo-36-1" class="ccm-layout ccm-layout-table  ccm-layout-name-ColumnTwo-Layout-1 "><div class="ccm-layout-row ccm-layout-row-1"><div class="ccm-layout-36-col-1 ccm-layout-cell ccm-layout-col ccm-layout-col-1 first" style="width:100%"><h2 style="text-align: left;"><span style="color: #cc1629;">Campaigning</span></h2>
<h3 style="text-align: left;">to stop shops heating and cooling the street, and to improve air quality inside</h3>
<div id="HTMLBlock1537" class="HTMLBlock">
<div class="respvid">
<iframe src="https://www.youtube.com/embed/h4kOVAc87_c" frameborder="0" allowfullscreen></iframe>
</div></div></div><div class="ccm-spacer"></div></div></div></div>            </div><!-- .col_4 ends -->
            <div class="col_4 omega">
                <h2 style="text-align: left;"><span style="color: #cc1629;">Consumers</span></h2>
<p style="text-align: left;">As a consumer, support the shops and restaurants who've joined us or display our logo. Close doors behind you. If you can't, follow our <a title="Guidelines" href="http://www.closethedoor.org.uk//index.php?cID=161">guidelines</a> when you speak to the staff or manager and let us know how it goes. If they won't Close the Door, shop elsewhere. Don't support their energy waste.</p>
<p style="text-align: left;">Read <a title="About us" href="http://www.closethedoor.org.uk//index.php?cID=160">about us</a>. Show your support by liking our <a href="http://www.facebook.com/pages/Close-the-door/128964107155996">Facebook page</a> or following us on <a href="https://twitter.com/Close_the_door" target="_blank">Twitter</a>. If you have some free time, you could <a title="Campaigners" href="http://www.closethedoor.org.uk//index.php?cID=176">join or start</a> a <a title="Local campaigns" href="http://www.closethedoor.org.uk//index.php?cID=167">local campaign</a>.</p>
<p style="text-align: center;"><a href="http://www.facebook.com/pages/Close-the-door/128964107155996" target="_blank"><img src="/files/7013/5991/0575/facebook.png" alt="facebook.png" width="32" height="32" /></a>        <a href="https://twitter.com/Close_the_door" target="_blank"><img src="/files/4213/5991/0577/twitter.png" alt="twitter.png" width="32" height="32" /></a></p>            </div><!-- .col_4 ends -->
        </div><!-- .row ends -->
        
        <hr />
        
        <div class="row">
            <div id="content" class="col_12">
                <div id="ccm-layout-wrapper-1345" class="ccm-layout-wrapper"><div id="ccm-layout-main-47-1" class="ccm-layout ccm-layout-table  ccm-layout-name-Main-Layout-1 "><div class="ccm-layout-row ccm-layout-row-1"><div class="ccm-layout-47-col-1 ccm-layout-cell ccm-layout-col ccm-layout-col-1 first" style="width:100%"><div id="ccm-layout-wrapper-1346" class="ccm-layout-wrapper"><div id="ccm-layout-main:layout1:cell1-51-1" class="ccm-layout ccm-layout-table  ccm-layout-name-Main:Layout1:Cell1-Layout-1 "><div class="ccm-layout-row ccm-layout-row-1"><div class="ccm-layout-51-col-1 ccm-layout-cell ccm-layout-col ccm-layout-col-1 first" style="width:100%">&nbsp;</div><div class="ccm-spacer"></div></div></div></div><div id="ccm-layout-wrapper-1347" class="ccm-layout-wrapper"><div id="ccm-layout-main:layout1:cell1-59-2" class="ccm-layout ccm-layout-table  ccm-layout-name-Main:Layout1:Cell1-Layout-2 "><div class="ccm-layout-row ccm-layout-row-1"><div class="ccm-layout-59-col-1 ccm-layout-cell ccm-layout-col ccm-layout-col-1 first" style="width:24%"><div class="ccm-layout-col-spacing"><h2 style="text-align: left;"><span style="color: #cc1629;">Highlights</span></h2><style >.unoslider_edit_disable{width:100%;min-height:20px;background:#999999;padding:10px;text-align:center;color:#fff}
.unoslider_edit_disable.error{color:#cf0000}
a:focus{outline:none!important;}
</style>	
<div class="unoslider-elegant">
<ul id="unoslider1527" class="unoslider ">
		
<li>
<a href="/news/archive/sustainable-city-awards-2016/">	
<img src="/files/3714/5684/6555/sustainable-cities.png"  title="29/2/16: Campaign Shortlisted for UKs foremost Sustainability Awards" />	
</a></li>
		
<li>
<a href="/news/archive/round-table-discussion-john-lewis-ms-and-arup/">	
<img src="/files/6614/5684/6050/geze-balloon.jpg"  title="GEZE sponsored round table discussion at RIBA on 7/3/16" />	
</a></li>
		
<li>
<a href="/support/participating-retailers/archive/hm/">	
<img src="/files/1914/4923/3199/hm.png"  title="H&M join the campaign" />	
</a></li>
		
<li>
<a href="/about-us/our-research/">	
<img src="/files/4814/2678/5909/air-quality-research.jpg"  title="19/3/2015: New shop air pollution research from leading universities" />	
</a></li>
		
<li>
<a href="/support/endorsements/archive/dr-ben-barratt/">	
<img src="/files/"  title="19/3/2015: Dr Ben Barratt comments on new research" />	
</a></li>
		
<li>
<a href="/support/participating-retailers/archive/home-retail-group/">	
<img src="/files/4714/2538/5142/home-retail-group.jpg"  title="03/02/2015: Home Retail Group joins the campaign" />	
</a></li>
		
<li>
<a href="/news/archive/observer-magazine-article/">	
<img src="/files/3414/2109/8238/theguardian.png"  title="11/01/2015: Observer magazine article" />	
</a></li>
		
<li>
<a href="/news/archive/retail-environment-magazine-article/">	
<img src="/files/2614/1902/5984/retail-environment.jpg"  title="Retail Environment Magazine article" />	
</a></li>
		
<li>
<a href="/news/archive/boots-endorses-campaign/">	
<img src="/files/4114/0185/8278/boots.png"  title="Boots endorses the campaign" />	
</a></li>
		
<li>
<a href="/news/archive/bbc1-inside-out-east/">	
<img src="/files/7713/6151/8680/inside-out.jpg"  title="BBC Inside Out East cover the campaign" />	
</a></li>
		
<li>
<a href="/news/archive/radio-4-world-weekend-cover-campaign/">	
<img src="/files/4813/9016/1662/r4_logo.png"  title="Coverage on BBC R4" />	
</a></li>
</ul>
</div>

<div style="clear:both;width:100%;height:10px;display:block"></div>
<!-- slider initializer -->
<script type='text/javascript'> 
	$(document).ready(function(){ 
		$('#unoslider1527').unoslider({
		width: 250 ,height: 250 ,scale: true ,responsive: true ,mobile: false,touch: true ,preloader: 'progress' ,tooltip: true ,order: 'in-order' ,indicator:false,navigation:false,slideshow: { autostart: true,speed: '7',timer: false,hoverPause: false,continuous: true,infinite: true}, preset:["alternate_horizontal","alternate_vertical","bar_fade_bottom","bar_fade_left","bar_fade_random","bar_fade_right","bar_fade_top","bar_slide_bottomright","bar_slide_random","bar_slide_topleft","bar_slide_topright","blind_bottom","blind_left","blind_right","blind_top","chess","explode","fade","flash","fountain","h_slide_left","h_slide_right","implode","shot_left","shot_right","spiral","spiral_reversed","sq_appear","sq_diagonal","sq_diagonal_rev","sq_drop","sq_fade_diagonal","sq_fade_diagonal_rev","sq_fade_random","sq_flyoff","sq_random","sq_squeeze","squeez","stretch","v_slide_bottom","v_slide_top","zipper_left","zipper_right"]	
				
				});
		  }); 
		</script>
		
		</div></div><div class="ccm-layout-59-col-2 ccm-layout-cell ccm-layout-col ccm-layout-col-2 " style="width:52%"><div class="ccm-layout-col-spacing">	<div id="blockStyle1000MainLayout1Cell1Layout2Cell262" class=" ccm-block-styles" >
<h2><span style="color: #cc1629;">What we do</span></h2>
<ul>
<li>Directly approach shops, restaurants and national chains, and invite them to join the campaign</li>
<li>Give individual retailers, branch managers and head offices the necessary information to help support their decision to join, including information on environmental impact, healthy working conditions for staff and how to ensure footfall is not reduced</li>
<li><span style="line-height: 1.5;">Supply stickers for doors or windows, allowing consumers to easily recognise and support participating retailers</span></li>
<li>Raise awareness of the issue and provide positive publicity for participating retailers through online, local and national media campaigns</li>
<li>Work with local councils and lobby government to change behaviour on the high street</li>
<li>Monitor shops and restaurants throughout the year</li>
<li>Commission research into the effects of a closed door for businesses</li>
</ul></div></div></div><div class="ccm-layout-59-col-3 ccm-layout-cell ccm-layout-col ccm-layout-col-3 last" style="width:23.99%">&nbsp;</div><div class="ccm-spacer"></div></div></div></div></div><div class="ccm-spacer"></div></div></div></div>	

	
	<script type="text/javascript">
		$(function() {
			$("div#makeMeScrollable1528").smoothDivScroll({ 
				autoScrollingMode: "always",
				autoScrollingDirection: "endlessLoopRight",
				autoScrollingStep: 1,
				autoScrollingInterval: 20,
				startAtElementId: "firstImageScroll",
				visibleHotSpots: "",
				setupComplete: function(eventObj, data) {
					$('#makeMeScrollableLoader1528').hide();
					$('#makeMeScrollable1528').css('visibility','visible');
				}
			});
			
						    		

		});
	</script>
<style type="text/css">
	#makeMeScrollable1528	{
		width:100%;
		height: auto;
		position: relative;
	}
	
	#makeMeScrollable1528 div.scrollableArea div,#makeMeScrollable1528 div.scrollableArea img
	{
		position: relative;
		float: left;
		padding: 0;
	}
	#makeMeScrollable1528 div.scrollableArea div.smoothinwrap{
		margin-right:50px;
	}
	
</style>
<div id="makeMeScrollableLoader1528" class="makeMeScrollableLoader">
		<img src="http://ctd-staging.maisey.uk/packages/jb_smooth/blocks/jb_smooth/images/ajax-loader.gif" />
</div>
<div id="makeMeScrollable1528" style="visibility:hidden;">
		<div class="scrollingHotSpotLeft"></div>
		<div class="scrollingHotSpotRight"></div>
		<div class="scrollWrapper">
			<div class="scrollableArea">
			
							<div class='smoothinwrap' style='width:134px;height:50px'><a href="/support/participating-retailers/archive/marks-and-spencer/" >					<img src="/files/cache/39a9a2521e7014c4ff1ada1aa73ffb82.jpg" id="firstImageScroll" alt="marksandspencer.png" height="50" width="134" class='capt' rel='caption-137' />
					
					</a></div>
								<div class='smoothinwrap' style='width:80px;height:50px'><a href="/support/participating-retailers/archive/born/" >					<img src="/files/cache/26f536d52fa8a38a8989dbbeb367178e.jpg"  alt="born.png" height="50" width="80" class='capt' rel='caption-133' />
					
					</a></div>
								<div class='smoothinwrap' style='width:183px;height:50px'><a href="/support/participating-retailers/archive/john-lewis-waitrose/" >					<img src="/files/cache/124db1fcf27145a479b3d5922bf56485.jpg"  alt="johnlewis.png" height="50" width="183" class='capt' rel='caption-136' />
					
					</a></div>
								<div class='smoothinwrap' style='width:173px;height:50px'><a href="/support/participating-retailers/archive/tesco/" >					<img src="/files/cache/94f94134d152a1cd1e811e97aa20db44.jpg"  alt="tesco.png" height="50" width="173" class='capt' rel='caption-141' />
					
					</a></div>
								<div class='smoothinwrap' style='width:147px;height:50px'><a href="/support/participating-retailers/archive/wickes-travis-perkins/" >					<img src="/files/cache/6bbed2c942d6c7380547cf4702e34b98.jpg"  alt="Wickes.png" height="50" width="147" class='capt' rel='caption-144' />
					
					</a></div>
								<div class='smoothinwrap' style='width:204px;height:50px'><a href="/support/participating-retailers/archive/aspace/" >					<img src="/files/cache/3fedd63bef7fb86d9c96d21334d61c0a.jpg"  alt="aspace.png" height="50" width="204" class='capt' rel='caption-132' />
					
					</a></div>
								<div class='smoothinwrap' style='width:263px;height:50px'><a href="/support/participating-retailers/archive/selfridges/" >					<img src="/files/cache/890cf2d6c6fae4d59e40246fd6017c9e.jpg"  alt="selfridges.png" height="50" width="263" class='capt' rel='caption-140' />
					
					</a></div>
								<div class='smoothinwrap' style='width:163px;height:50px'><a href="/support/participating-retailers/archive/pramo/" >					<img src="/files/cache/f56b3ed78fb772b4e930719b002a84cd.jpg"  alt="Paramo.png" height="50" width="163" class='capt' rel='caption-220' />
					
					</a></div>
								<div class='smoothinwrap' style='width:73px;height:50px'><a href="/support/participating-retailers/archive/home-retail-group/" >					<img src="/files/cache/067ae7c7af4a5bbfb7efb0db3ea76e3c.jpg"  alt="argos.png" height="50" width="73" class='capt' rel='caption-289' />
					
					</a></div>
								<div class='smoothinwrap' style='width:154px;height:50px'><a href="/news/archive/oxfam-supports-close-the-door-campaign/" >					<img src="/files/cache/951f88a1971f8af748ea754222e63ca6.jpg"  alt="oxfam.png" height="50" width="154" class='capt' rel='caption-160' />
					
					</a></div>
								<div class='smoothinwrap' style='width:50px;height:50px'><a href="/support/participating-retailers/archive/wickes-travis-perkins/" >					<img src="/files/cache/6036f65395cd89eb6e81fba1bddce4bc.jpg"  alt="travisperkins.png" height="50" width="50" class='capt' rel='caption-142' />
					
					</a></div>
								<div class='smoothinwrap' style='width:204px;height:50px'><a href="/support/participating-retailers/archive/john-lewis-waitrose/" >					<img src="/files/cache/79bafde872bebbc00687bafd67a35035.jpg"  alt="waitrose.png" height="50" width="204" class='capt' rel='caption-143' />
					
					</a></div>
								<div class='smoothinwrap' style='width:50px;height:50px'><a href="/support/participating-retailers/archive/costa-coffee/" >					<img src="/files/cache/aaba72306d61f360a54ad56881c5f554.jpg"  alt="costa.png" height="50" width="50" class='capt' rel='caption-134' />
					
					</a></div>
								<div class='smoothinwrap' style='width:131px;height:50px'><a href="/support/participating-retailers/archive/fenwick/" >					<img src="/files/cache/5cbafbea74948878eb3f6d3c5b88c134.jpg"  alt="fenwick.png" height="50" width="131" class='capt' rel='caption-135' />
					
					</a></div>
								<div class='smoothinwrap' style='width:82px;height:50px'><a href="/support/participating-retailers/archive/boots-member-alliance-boots/" >					<img src="/files/cache/b67ac63d8ad3035a37dab398aef99bf2.jpg"  alt="boots-retailer-slider.png" height="50" width="82" class='capt' rel='caption-264' />
					
					</a></div>
								<div class='smoothinwrap' style='width:50px;height:50px'><a href="/support/participating-retailers/archive/neals-yard/" >					<img src="/files/cache/32ecba9a054e7f9ed35b71fd0b00161c.jpg"  alt="nealsyard.png" height="50" width="50" class='capt' rel='caption-138' />
					
					</a></div>
								<div class='smoothinwrap' style='width:75px;height:50px'><a href="/support/participating-retailers/archive/hm/" >					<img src="/files/cache/e74956d1ee34795ea3b03cd726a5cb3a.jpg"  alt="HM.png" height="50" width="75" class='capt' rel='caption-331' />
					
					</a></div>
								<div class='smoothinwrap' style='width:284px;height:50px'><a href="/support/participating-retailers/archive/home-retail-group/" >					<img src="/files/cache/773e14f89a537d8000b96c192131c912.jpg"  alt="homebase.png" height="50" width="284" class='capt' rel='caption-294' />
					
					</a></div>
							</div>
		</div>
	</div>
	<script type="text/javascript">
		$(window).load(function() {
		 	$("div#makeMeScrollable1528").smoothDivScroll("showHotSpotBackgrounds");
		 			 });
		
	</script>            </div><!-- #content ends -->
        </div><!-- .row ends -->
    
    </div><!-- #wrapper ends -->
    
    <footer>
    	<div class="row">
            <div class="col_3">
                            </div><!-- .col_3 ends -->
            <div class="col_3">
                            </div><!-- .col_3 ends -->
            <div class="col_3">
                            </div><!-- .col_3 ends -->
            <div class="col_3 last">
                            </div><!-- .col_3 ends -->
        </div><!-- .row ends -->
        <div class="row">
            <div id="credits" class="col_12 clearboth">
                <p class="left">&copy; 2023 Close the Door. All Rights Reserved. 			<span class="sign-in"><a href="/index.php/login/">Login</a>.</span>
	</p>
    			<p class="right">
				<a href="/news/archive/geze-becomes-official-supporter-close-door/">
					<img border="0" class="ccm-image-block" alt="GreenQloud" src="/files/3214/5674/9243/geze-logo.png" width="137" height="55" style="opacity: 1;" alt="Sponsored and hosted by GreenQloud"/>
				</a>
			</p>
            </div><!-- #credits ends -->
        </div><!-- .row ends -->
    </footer><!-- footer ends -->

</div><!-- #container ends -->


</body>
</html>
